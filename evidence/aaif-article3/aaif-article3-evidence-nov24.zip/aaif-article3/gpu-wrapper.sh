#!/bin/bash
set -o pipefail
umask 077

export LD_LIBRARY_PATH="/usr/lib64-nvidia:${LD_LIBRARY_PATH:-}"

TRACE_DIR=$(mktemp -d /content/aaif-article3/traces/server-XXXXXXXX)

date -u +"%Y-%m-%dT%H:%M:%SZ" > "$TRACE_DIR/start-time.txt"

tee "$TRACE_DIR/mcp-in.jsonl" |
    /content/gpu-mcp-server/gpu-mcp-server     2>"$TRACE_DIR/mcp-stderr.log" |
    tee "$TRACE_DIR/mcp-out.jsonl"

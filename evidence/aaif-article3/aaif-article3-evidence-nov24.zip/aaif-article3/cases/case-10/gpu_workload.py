
import torch
import time
import os

assert torch.cuda.is_available()

print("PID:", os.getpid(), flush=True)
print("GPU:", torch.cuda.get_device_name(0), flush=True)

a = torch.randn((8192, 8192), device="cuda")
b = torch.randn((8192, 8192), device="cuda")
c = torch.empty_like(a)

torch.mm(a, b, out=c)
torch.cuda.synchronize()

print(
    "Allocated MiB:",
    torch.cuda.memory_allocated() / 1024**2,
    flush=True
)

print("WORKLOAD READY", flush=True)

deadline = time.monotonic() + 600
iterations = 0

while time.monotonic() < deadline:
    torch.mm(a, b, out=c)
    torch.cuda.synchronize()
    iterations += 1

print("Iterations:", iterations, flush=True)
print("WORKLOAD COMPLETED", flush=True)
